package com.example.rest_client_in_android;

import java.util.ArrayList;
import java.util.List;

public class Track {
    private String nombre;
    private String imagenURL;

    public Track (String nombre, String imagenURL){
        this.nombre=nombre;
        this.imagenURL=imagenURL;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getImagenURL() {
        return imagenURL;
    }
    public void setImagenURL(String imagenURL) {
        this.imagenURL = imagenURL;
    }

    public static void setData(){

    }

    public static List<Track> getData() {
        // Aquí deberías crear y devolver una lista de artículos
        List<Track> tracks = new ArrayList<>();

        // Agregar artículos a la lista (esto es solo un ejemplo, ajusta según tus necesidades)
        tracks.add(new Track("A","B"));

        return tracks;
    }
}
